package Ejercicio2;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

/*2.b Escribir las líneas sin buffer, utilizando OutputStream con métodos de la clase Files y
luego leerlas con el método correspondiente.*/

public class Ejc2B {
	
	private static Scanner teclado;
	
	public static void main(String []args){
		
		ArrayList<String> frase = new ArrayList<String>();
		teclado = new Scanner(System.in);
		
		System.out.println("Escriba el nombre del archivo");
		String archivo = teclado.nextLine();
		
		Path file= Paths.get(archivo+".txt");
		//sysout+ ctrl+space
	}

}
