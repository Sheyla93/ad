package Ejercicio2;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

/**2A.Desarrolla una clase que solicite frases al usuario, mediante un diálogo y las escriba en un
fichero. El nombre del fichero donde se escribirán las frases lo proporcionará el usuario
también. El fichero debe existir en el directorio actual. Si durante el proceso ocurre algún error
deberás gestionarlo, para informar al usuario y finalizar. Resuelve el ejercicio almacenando
todas las frases en una lista hasta que el usuario no quiera introducir más y después crea
distintos métodos para:
a. Escríbir las frases todas a la vez con write de la clase Files, y luego leerlas de igual
forma.*/

public class Ejc2A {
	private static Scanner teclado;
	
	public static void main(String[]args){
		
		ArrayList<String> frase = new ArrayList<String>();
		teclado = new Scanner(System.in);
		System.out.println("Por favor escriba el nombre del archivo: \n");
		String archivo = teclado.nextLine();
		Path file = Paths.get(archivo+".txt");
		Charset charset = Charset.forName("UTF-8");
		boolean bool =false;
		
		//Creamos un BufferedWriter de java.io de forma eficiente utilizando Files de java.nio
		try (BufferedWriter writer = Files.newBufferedWriter(file, charset)) {
		
		String escribir;
		while(bool==false){
			System.out.println("Escriba una frase, para terminar escriba /n");
			escribir= teclado.nextLine();
			if(escribir.equals("/n")){
				bool=true;
			}else{
				frase.add(escribir);
			}
		}
		//Iterator, permite el desplazamiento a traves de una coleccion
		Iterator<String> iterator	= frase.iterator();
		//mientras se hace el bucle, sigue escribiendo
		while (iterator.hasNext()){
			writer.write(iterator.next());
			writer.newLine();
		}
		//cierre del bufferWriter
		writer.close();
		/**Para mostrar todo el contenido escrito
			System.out.println("Se muestra por pantalla el contenido de su archivo");
			
			List<String> ver;
			ver=Files.readAllLines(file);
			System.out.println(ver);
		 */
		} catch (IOException io) {
		    System.err.format("IOException: %s%n", io);
		}
	}
}
