package cuadernillo1;
/*	Estudia las clases Paths y Path de Java, y realiza un ejercicio que utilice al menos los siguientes métodos:
 *  get() de la clase Paths, y toString(), getFileName(), getName(0), getNameCount(),subpath(0,2), getParent(),
 *  getRoot(), toURI(), toAbsolutePath(), toRealPath(), resolve(), relativize(), startsWith(), endsWith() 
 *  de la clase Path.*/

import java.net.URI;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Ejc1 {
	
	public static void main(String[]args){
		
		Path p1 = Paths.get("ejercicio1.txt");
		Path p2 =Paths.get("Hola Soy Sheila");
			System.out.println(p1.toString());
		
			System.out.println(p2.toAbsolutePath());//muestra la ubicacion donde se encuentra
			
			System.out.println(p2.getFileName());//muestra el nombre del fichero
				
		//URI: Creamos un path a partir de una URI, muestra por pantalla la uri completa
		Path p3 = Paths.get(URI.create("file:///D:/PracticasEclipse/Cuadernillo1/ejercicio1.txt"));
			System.out.println(p3.toUri());
		
			System.out.println(p3.getParent());
			
			System.out.println(p3.getNameCount());
			
			System.out.println(p3.resolve(p2));
			
			//System.out.println(p2.relativize(p2));
			
			System.out.println(p3.getRoot());
			
			System.out.println(p1.startsWith(p1));
			
			System.out.println(p2.endsWith(p1));
			
			//System.out.println(p1.toRealPath(options));
			
			System.out.println(p3.subpath(0, 3));//si cambio el 3 por otro numero cambia 

			System.out.println(p3.getName(1));




	}
}
